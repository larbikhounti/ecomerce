<?php

// get db connection
$config = 'mysql:host=localhost;dbname=eco';
$user = 'root';
$pass = '';
$dbc = new PDO($config, $user, $pass);
