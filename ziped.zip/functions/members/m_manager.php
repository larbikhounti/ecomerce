<?php
// this file is used for managing memebers only 
// mohamed khounti
// 1/4/2021
session_start();
// connect to database 
include "../../includes/mysql_connections/connect.php";

  //check if its coming from POST request
  if($_SERVER['REQUEST_METHOD'] == 'POST'){
    // get the id of the user 
    // delete or update a user 
    
  }


